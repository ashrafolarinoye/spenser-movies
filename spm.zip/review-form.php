<?php

// Ratings

$arrayRatings = range(1, 10);

require './views/reviewform.view.php';

?>